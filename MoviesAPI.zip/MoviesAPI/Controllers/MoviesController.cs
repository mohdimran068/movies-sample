﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        private readonly MoviesContext _context;

        public MoviesController(MoviesContext context)
        {
            _context = context;
        }

        // GET: api/movies
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Movies>>> GetMovies()
        {
            return await _context.Movies.ToListAsync();
        }
        

        // PUT: api/movies/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateMovie(int id, Movies movie)
        {
            if(id!=movie.MovieID)
            {
                return BadRequest();
            }
            _context.Entry(movie).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MovieExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // GET: api/movies/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Movies>> GetMovie(int id)
        {
            var movieItem = await _context.Movies.FindAsync(id);

            if (movieItem == null)
            {
                return NotFound();
            }

            return movieItem;
        }

        // POST: api/movies
        [HttpPost]
        public async Task<ActionResult<Movies>> AddMovie(Movies movieItem)
        {
            try
            {
                _context.Movies.Add(movieItem);
                await _context.SaveChangesAsync();
                return CreatedAtAction("GetMovie", new { id = movieItem.MovieID }, movieItem);
            }
            catch (Exception ex)
            {
                return CreatedAtAction("GetMovie", new { id = movieItem.MovieID }, ex);
            }
        }

        // DELETE: api/movies/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Movies>> DeleteMovie(int id)
        {
            var movieItem = await _context.Movies.FindAsync(id);
            if (movieItem == null)
            {
                return NotFound();
            }

            _context.Movies.Remove(movieItem);
            await _context.SaveChangesAsync();

            return movieItem;
        }

        private bool MovieExists(int id)
        {
            return _context.Movies.Any(e => e.MovieID == id);
        }
    }
}
