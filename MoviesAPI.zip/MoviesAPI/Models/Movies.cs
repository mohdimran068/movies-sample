﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebAPI.Models
{
    public class Movies
    {
        [Key]
        public int MovieID { get; set; }
        [Required]
        [Column(TypeName ="nvarchar(500)")]
        public string MovieTitle { get; set; }
        [Required]
        [Column(TypeName = "varchar(16)")]
        public string ReleaseDate { get; set; }
        [Required]
        [Column(TypeName = "varchar(500)")]
        public string Genre { get; set; } 
        [Required]
        [Column(TypeName = "varchar(500)")]
        public string Director { get; set; }
    }
}
