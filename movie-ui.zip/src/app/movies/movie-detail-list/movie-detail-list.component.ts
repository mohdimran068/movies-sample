import { MovieDetail } from '../../shared/movie-detail.model';
import { MovieDetailService } from '../../shared/movie-detail.service';
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-movie-detail-list',
  templateUrl: './movie-detail-list.component.html',
  styles: []
})
export class MovieDetailListComponent implements OnInit {

  constructor(private service: MovieDetailService,
    private toastr: ToastrService) { }

  ngOnInit() {
    this.service.refreshList();
  }

  populateForm(pd: MovieDetail) {
    this.service.formData = Object.assign({}, pd);
  }

  onDelete(movieId) {
    if (confirm('Are you sure to delete this record ?')) {
      this.service.deleteMovie(movieId)
        .subscribe(res => {
          debugger;
          this.service.refreshList();
          this.toastr.warning('Deleted successfully', 'Movie Register');
        },
          err => {
            debugger;
            console.log(err);
          })
    }
  }

}
