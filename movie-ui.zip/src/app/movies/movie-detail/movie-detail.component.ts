import { MovieDetailService } from '../../shared/movie-detail.service';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-movie-detail',
  templateUrl: './movie-detail.component.html',
  styles: []
})
export class MovieDetailComponent implements OnInit {

  constructor(private service: MovieDetailService,
    private toastr: ToastrService) { }

  ngOnInit() {
    this.resetForm();
  }


  resetForm(form?: NgForm) {
    if (form != null)
      form.form.reset();
    this.service.formData = {
      MovieID: 0,
      MovieTitle: '',
      ReleaseDate: '',
      Genre: '',
      Director: ''
    }
  }

  onSubmit(form: NgForm) {
    if (this.service.formData.MovieID == 0)
      this.insertRecord(form);
    else
      this.updateRecord(form);
  }

  insertRecord(form: NgForm) {
    this.service.postMovie().subscribe(
      res => {
        debugger;
        this.resetForm(form);
        this.toastr.success('Submitted successfully', 'Movie Register');
        this.service.refreshList();
      },
      err => {
        debugger;
        console.log(err);
      }
    )
  }
  updateRecord(form: NgForm) {
    this.service.updateMovie().subscribe(
      res => {
        this.resetForm(form);
        this.toastr.info('Submitted successfully', 'Movie Register');
        this.service.refreshList();
      },
      err => {
        console.log(err);
      }
    )
  }

}
