import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
 
import { ToastrModule } from 'ngx-toastr';
import { AppComponent } from './app.component';
import { MovieDetailsComponent } from './movies/movie-details.component';
import { MovieDetailComponent } from './movies/movie-detail/movie-detail.component';
import { MovieDetailListComponent } from './movies/movie-detail-list/movie-detail-list.component';
import { MovieDetailService } from './shared/movie-detail.service';

@NgModule({
  declarations: [
    AppComponent,
    MovieDetailsComponent,
    MovieDetailComponent,
    MovieDetailListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()
  ],
  providers: [MovieDetailService],
  bootstrap: [AppComponent]
})
export class AppModule { }
