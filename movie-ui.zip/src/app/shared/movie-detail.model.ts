export class MovieDetail {
    MovieID :number;
    MovieTitle: string;
    ReleaseDate: string;
    Genre: string;
    Director: string;
}
