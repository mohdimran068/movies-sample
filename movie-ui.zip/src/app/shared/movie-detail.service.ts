import { MovieDetail } from './movie-detail.model';
import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class MovieDetailService {
  formData: MovieDetail= {
    MovieTitle: null,
    ReleaseDate: null,
    Genre : null,
    Director: null,
    MovieID: null
  };
  
  readonly rootURL = 'http://localhost:59035/api';
  list : MovieDetail[];

  constructor(private http: HttpClient) { }

  postMovie() {
    return this.http.post(this.rootURL + '/movies', this.formData);
  }
  updateMovie() {
    return this.http.put(this.rootURL + '/movies/'+ this.formData.MovieID, this.formData);
  }
  deleteMovie(id) {
    return this.http.delete(this.rootURL + '/movies/'+ id);
  }

  refreshList(){
    this.http.get(this.rootURL + '/movies')
    .toPromise()
    .then(res => this.list = res as MovieDetail[]);
  }
}
